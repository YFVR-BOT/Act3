package programasjava;

import java.util.Scanner;

public class AreaRectangulo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese el largo del rectángulo: ");
        double largo = scanner.nextDouble();
        
        System.out.print("Ingrese el ancho del rectángulo: ");
        double ancho = scanner.nextDouble();
        
        double area = largo * ancho;
        
        System.out.println("El área del rectángulo es: " + area);
    }
}
